#pragma once

int check_if_virus(char* path);
