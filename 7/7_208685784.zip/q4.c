#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/user.h>

int address_pid = 0x12345678;

int main(int argc, char **argv) {
    // Make the malware stop waiting for our output by forking a child process:
    if (fork() != 0) {
        // Kill the parent process so we stop waiting from the malware
        return 0;
    } else {
        // Close the output stream so we stop waiting from the malware
        fclose(stdout);
    }

    struct user_regs_struct st_registers;
    int stat;
    int bool_1 = ptrace(PTRACE_ATTACH, address_pid, NULL, NULL);


    if (bool_1 == -1) {
        perror("attach");
        return 1;
    }

    waitpid(address_pid, &stat, 0);
    if (WIFEXITED(stat)) {
        return 1;
    }

    while(1) {
        ptrace(PTRACE_SYSCALL, address_pid, 0, 0);
        waitpid(address_pid, &stat, 0);

        ptrace(PTRACE_GETREGS, address_pid, 0, &st_registers);
        
        long syscall = st_registers.orig_eax;
        if (syscall == 3) {
            st_registers.ebx = -1;
        }

        ptrace(PTRACE_SETREGS, address_pid, 0, &st_registers);
    
        ptrace(PTRACE_SYSCALL, address_pid, 0, 0);
        waitpid(address_pid, &stat, 0);
        if (WIFEXITED(stat)) {
            return 0;
        }
    }
    return 0;
}
