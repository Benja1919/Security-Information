#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


int pid = 0x12345678;
int addr_1 = 0x11112222;
int addr_2 = 0x22221111;

int main() {
    int stat, bool_1, bool_2, bool_3, bool_4;
    bool_1 = ptrace(PTRACE_ATTACH,pid,NULL,NULL);
    bool_2 = WIFEXITED(stat);
    bool_3 = ptrace(PTRACE_POKEDATA, pid, addr_1, addr_2);
    bool_4 = ptrace(PTRACE_DETACH,pid,NULL,NULL);
    if( bool_1 == -1){
        perror("attach");
        return 1;
    }
    waitpid(pid,&stat,0);
    if (bool_2){
        return 1;
    }
    if (bool_3 < 0){
        perror("poke text");
        return 1;
    }
    if (bool_4 == -1){
        perror("detach");
        return 1;
    }
    return 0;
}
