from q2_atm import ATM, ServerResponse


def extract_PIN(encrypted_PIN) -> int:
    """Extracts the original PIN string from an encrypted PIN."""
    bank = ATM()
    for i in range(10000):
        if bank.encrypt_PIN(i) == encrypted_PIN:
            return i


def extract_credit_card(encrypted_credit_card) -> int:
    """Extracts a credit card number string from its ciphertext."""
    bank = ATM()
    return round(encrypted_credit_card**(1/bank.rsa_card.e))


def forge_signature():
    """Forge a server response that passes verification."""
    return ServerResponse(1,1)
