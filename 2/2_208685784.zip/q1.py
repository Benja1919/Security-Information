class RepeatedKeyCipher:

    def __init__(self, key: bytes = bytes([0, 0, 0, 0, 0])):
        """Initializes the object with a list of integers between 0 and 255."""
        # WARNING: DON'T EDIT THIS FUNCTION!
        self.key = list(key)

    def encrypt(self, plaintext: str) -> bytes:
        """Encrypts a given plaintext string and returns the ciphertext."""
        size_key = len(self.key)
        arr = []
        counter = 0
        byted = bytearray(plaintext.encode('latin-1'))
        for i in byted:
            """xoring and handling length problem by modulu"""
            tmp = i^self.key[counter%size_key]
            arr.append(tmp)
            counter += 1
        return bytes(bytearray(arr))
        
    def decrypt(self, ciphertext: bytes) -> str:
        """Decrypts a given ciphertext string and returns the plaintext."""
        return self.encrypt(ciphertext.decode('latin-1')).decode('latin-1')



class BreakerAssistant:

    def plaintext_score(self, plaintext: str) -> float:
        """Scores a candidate plaintext string, higher means more likely."""
        """"Using the chi-sqaured method as seen in https://en.wikipedia.org/wiki/Chi_sqaured_test"""
        # Please don't return complex numbers, that would be just annoying.
        possibilities = {'a': 8.2, 'b': 1.5, 'c':2.5, 'd': 4.3, 'e': 13,  'f': 2.2, 'g':2, 'h': 6.1, 'i': 7, 'j': 0.15, 'k':0.77, 'l': 4,'m': 2.4, 'n': 6.7, 'o':7.5, 'p': 1.9, 'q': 0.095,  'r': 6, 's':6.3, 't': 9.1, 'u': 2.8, 'v': 0.98, 'w':2.4, 'x': 0.15 ,'y':2, 'z': 0.074, ' ':8.5 }
        reps = dict()
        for character in plaintext:
            if character in reps:
                reps[character] += 1
            else:
                reps[character] = 1
        points = 0
        for i in range(len(plaintext)):
            uni = ord(plaintext[i])
            if (uni < 0 or uni > 127):
                return -1;
            if (uni >=97 and uni <= 122):
                score = possibilities[plaintext[i]]
                rep = reps[plaintext[i]]
                points += (score*(len(plaintext)-rep)/len(plaintext))
        return points

    def brute_force(self, cipher_text: bytes, key_length: int) -> str:
        """Breaks a Repeated Key Cipher by brute-forcing all keys."""
        points = -1
        max_text = ""
        for op_key in range(2**(8*key_length)):
            key = op_key.to_bytes(key_length, byteorder='little')
            curr_key = RepeatedKeyCipher(key)
            curr_text = curr_key.decrypt(cipher_text)
            curr_points = self.plaintext_score(curr_text)
            if curr_points > points:
                points = curr_points
                max_text = curr_text
        return max_text
            
    def smarter_break(self, cipher_text: bytes, key_length: int) -> str:
        """Breaks a Repeated Key Cipher any way you like."""
        i = 0
        arr = []
        while i in range(key_length):
            points = -1
            key_curr = 0
            j = 0
            while j in range(2 ** 8):
                key = j.to_bytes(1, byteorder='little')
                curr_cipher = RepeatedKeyCipher(key)
                text = []
                index = 0
                for byte in cipher_text:
                    if index % key_length == i:
                        text.append(byte)
                    index += 1
                text = bytes(text)
                curr_score = self.plaintext_score(curr_cipher.decrypt(text))
                if curr_score > points:
                    points = curr_score
                    key_curr = j
                j+=1
            arr.append(key_curr)
            i+= 1
        return RepeatedKeyCipher(bytes(bytearray(arr))).decrypt(cipher_text)
