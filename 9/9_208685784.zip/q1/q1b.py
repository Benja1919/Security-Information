import time
import os
from scapy.all import *


WINDOW = 60
MAX_ATTEMPTS = 15


# Initialize your data structures here
packet_syns = dict()


blocked = set()  # We keep blocked IPs in this set


def on_packet(packet):
    """This function will be called for each packet.

    Use this function to analyze how many packets were sent from the sender
    during the last window, and if needed, call the 'block(ip)' function to
    block the sender.

    Notes:
    1. You must call block(ip) to do the blocking.
    2. The number of SYN packets is checked in a sliding window.
    3. Your implementation should be able to efficiently handle multiple IPs.
    """
    try:
        if packet[TCP].flags == 'S':
            curr_ip = packet[IP].src
            if curr_ip in packet_syns:
                arr = packet_syns[ip]
                arr.append(packet)
                while packet.time - arr[0].time > WINDOW:
                    arr.pop(0)
                if len(arr) > MAX_ATTEMPTS:
                    block(curr_ip)
                    packet_syns.pop(curr_ip)
                else:
                    packet_syns[curr_ip] = arr
            else:
                packet_syns[curr_ip] = list(packet)
    except:
        return
                


def generate_block_command(ip: str) -> str:
    """Generate a command that when executed in the shell, blocks this IP.

    The blocking will be based on `iptables` and must drop all incoming traffic
    from the specified IP."""
    return "sudo iptables -A INPUT -s %s -j DROP" % (ip)


def block(ip):
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    os.system(generate_block_command(ip))
    blocked.add(ip)


def is_blocked(ip):
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    return ip in blocked


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    sniff(prn=on_packet)


if __name__ == '__main__':
    main()
