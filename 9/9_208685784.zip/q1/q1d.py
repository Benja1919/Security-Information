from scapy.all import *


def on_packet(packet):
    """Implement this to send a SYN ACK packet for every SYN.

    Notes:
    1. Use *ONLY* the `send` function from scapy to send the packet!
    """
    try:
        if packet[TCP].flags == 'S':
            curr_tcp = packet[TCP]
            curr_ip = packet[IP]
            send(IP(dst=curr_ip.src)/TCP(flags='SA', sport=curr_tcp.dport, dport = curr_tcp.sport, seq = curr_tcp.ack, ack=curr_tcp.seq+1))
    except:
        return


def main(argv):
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    sniff(prn=on_packet)


if __name__ == '__main__':
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    import sys
    sys.exit(main(sys.argv))
