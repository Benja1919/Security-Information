import socket
from Crypto.Cipher import AES
from base64 import b64encode, b64decode
from cryptography.hazmat.primitives import padding

def receive_message(port: int) -> str:
    """Receive *encrypted* messages on the given TCP port.

    As Winston sends encrypted messages, re-implement this function so to
    be able to decrypt the messages.

    Notes:
    1. The encryption is based on AES.
    2. Julia and Winston already have a common shared key, just define it on your own.
    3. Mind the padding! AES works in blocks of 16 bytes.
    """
    key = 'abcdefghijklmnopqrstuvwxyzabcdef'
    iv = '1122334455667788'
    listener = socket.socket()
    try:
        listener.bind(('', port))
        listener.listen(1)
        connection, address = listener.accept()
        try:
            cipher = b64decode(connection.recv(1024).decode('latin-1'))
            aes = AES.new(key.encode('utf8'), AES.MODE_CBC, iv.encode('utf8'))
            data = aes.decrypt(cipher)
            unpad = padding.PKCS7(128).unpadder()
            output = unpad.update(data) + unpad.finalize()
            return output.decode('latin-1')
        finally:
            connection.close()
    finally:
        listener.close()


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    message = receive_message(1984)
    print('received: %s' % message)


if __name__ == '__main__':
    main()
