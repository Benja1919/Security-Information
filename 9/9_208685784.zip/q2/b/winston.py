import socket
from Crypto.Cipher import AES
from base64 import b64encode, b64decode
from cryptography.hazmat.primitives import padding


def send_message(ip: str, port: int):
    """Send an *encrypted* message to the given ip + port.

    Julia expects the message to be encrypted, so re-implement this function accordingly.

    Notes:
    1. The encryption is based on AES.
    2. Julia and Winston already have a common shared key, just define it on your own.
    3. Mind the padding! AES works in blocks of 16 bytes.
    """
    string = b'I love you'
    key = 'abcdefghijklmnopqrstuvwxyzabcdef'
    iv = '1122334455667788'
    pad = padding.PKCS7(128).padder()
    data = pad.update(string) + pad.finalize()
    aes = AES.new(key.encode('utf8'), AES.MODE_CBC, iv.encode('utf8'))
    cipher = aes.encrypt(data)
    connection = socket.socket()
    try:
        connection.connect((ip, port))
        connection.send(b64encode(cipher))
    finally:
        connection.close()


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    send_message('127.0.0.1', 1984)


if __name__ == '__main__':
    main()
