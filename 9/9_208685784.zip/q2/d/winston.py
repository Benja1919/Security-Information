import socket
import math
from scapy.all import *


SRC_PORT = 65000


def send_message(ip: str, port: int):
    """Send a *hidden* message to the given ip + port.

    Julia expects the message to be hidden in the TCP metadata, so re-implement
    this function accordingly.

    Notes:
    1. Use `SRC_PORT` as part of your implementation.
    """
    string = "I love you"
    string_to_bits = ''.join(format(ord(i), '08b') for i in string)
    num_of_packets = math.ceil(len(string_to_bits) / 3)
    i = 0
    while i in range(num_of_packets):
        a = 3*i
        curr = string_to_bits[a:a+3]
        if i == num_of_packets-1 and len(curr) != 3:
            curr = curr + '0'*(3-len(curr))
        data = int(curr)
        send(IP(dst=ip) / TCP(flags='SA', sport=SRC_PORT, dport=port, seq=i, ack=num_of_packets, reserved=data))
        i = i + 1
        


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    send_message('127.0.0.1', 1984)


if __name__ == '__main__':
    main()
