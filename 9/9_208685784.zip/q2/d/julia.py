import socket
from scapy.all import *


SRC_PORT = 65000
list_bit = list()

def receive_message(port: int) -> str:
    """Receive *hidden* messages on the given TCP port.

    As Winston sends messages encoded over the TCP metadata, re-implement this
    function so to be able to receive the messages correctly.

    Notes:
    1. Use `SRC_PORT` as part of your implementation.
    """

    data = ""
    string = ""
    i = 0
    sniff(prn=packet_parsing, stop_filter=(lambda x: len(list_bit) == x[TCP].ack), iface = get_if_list())
    while i < len(list_bit):
        data = data + '0' * (3-len("{0:b}".format(list_bit[i]))) + "{0:b}".format(list_bit[i])
        i = i + 1
    for i in range(0, len(data), 8):
        tmp = data[i:i+8]
        dec = int(tmp, 2)
        string = string + chr(dec)
    return string
    
    
def packet_parsing(packet):
    try:
        if packet[TCP].sport == SRC_PORT and len(list_bit) == packet[TCP].seq:
            list_bit.append(packet[TCP].reserved)
    except:
        return


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    message = receive_message(1984)
    print('received: %s' % message)


if __name__ == '__main__':
    main()
