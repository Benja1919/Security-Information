def check_message(path: str) -> bool:
    """
    Return True if `msgcheck` would return 0 for the file at the specified path,
    return False otherwise.
    :param path: The file path.
    :return: True or False.
    """
    with open(path, 'rb') as reader:
        actions = int.from_bytes(reader.read(1), "little")
        second = int.from_bytes(reader.read(1), "little")
        val = 8
        i = 0
        while i < actions:
            curr = int.from_bytes(reader.read(1), "little")
            val = val ^ curr
            i = i+1
        return second == val
            

def main(argv):
    if len(argv) != 2:
        print('USAGE: python {} <msg-file>'.format(argv[0]))
        return -1
    path = argv[1]
    if check_message(path):
        print('valid message')
        return 0
    else:
        print('invalid message')
        return 1


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
