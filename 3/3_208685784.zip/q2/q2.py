from infosec.core import assemble


def patch_program_data(program: bytes) -> bytes:
    """
    Implement this function to return the patched program. This program should
    execute lines starting with #!, and print all other lines as-is.

    Use the `assemble` module to translate assembly to bytes. For help, in the
    command line run:

        ipython3 -c 'from infosec.core import assemble; help(assemble)'

    :param data: The bytes of the source program.
    :return: The bytes of the patched program.
    """
    first_deadzone = 1587
    second_deadzone = 1485
    prog = bytearray(program)
    first_patch = bytearray(assemble.assemble_file("./patch1.asm"))
    len_first_patch = len(first_patch)
    second_patch = bytearray(assemble.assemble_file("./patch2.asm"))
    len_second_patch = len(second_patch)
    
    i = 0
    while i < len_first_patch:
        prog[i+first_deadzone] = first_patch[i]
        i = i+1
    i = 0
    while i < len_second_patch:
        prog[i+second_deadzone] = second_patch[i]
        i = i+1
        
    finalval = bytes(prog)
    return finalval
    

def patch_program(path):
    with open(path, 'rb') as reader:
        data = reader.read()
    patched = patch_program_data(data)
    with open(path + '.patched', 'wb') as writer:
        writer.write(patched)


def main(argv):
    if len(argv) != 2:
        print('USAGE: python {} <readfile-program>'.format(argv[0]))
        return -1
    path = argv[1]
    patch_program(path)
    print('done')


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
