from . import server


if __name__ == '__main__':
    server.run()
